import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="Bus ETA Tracker", layout="wide")
st.title("🚌 Real-time Bus ETA Prediction")

# Example map
m = folium.Map(location=[40.7128, -74.0060], zoom_start=12)
folium.Marker([40.7128, -74.0060], popup="Bus 101").add_to(m)
st_folium(m, width=700, height=500)